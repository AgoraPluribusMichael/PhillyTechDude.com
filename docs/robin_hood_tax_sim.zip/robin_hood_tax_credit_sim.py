import json

NUM_WORKERS = 150_000_000
TAX_RATE = 0.15

def generate_html_table():
    with open("tax_relief_table.html", "w") as html_file:
        html_file.write(f"<tr><td style=\"font-weight: bold;\">Year</td>")
        for year in sorted(tax_relief_dict.keys()):
            html_file.write(f"<td>{year}</td>")
        html_file.write(f"</tr>\n")
        html_file.write(f"<tr><td style=\"font-weight: bold;\">Tax Relief</td>")
        for year in sorted(tax_relief_dict.keys()):
            html_file.write(f"<td>${int(tax_relief_dict[year])}</td>")
        html_file.write(f"</tr>\n")


if __name__ == "__main__":
    tax_revenue_dict = dict()

    last_net_worth = 0
    curr_net_worth = 0
    date = None

    # Wealth distribution data from the Federal Reserve
    # https://www.federalreserve.gov/releases/z1/dataviz/dfa/distribute/table/
    # https://www.federalreserve.gov/releases/z1/dataviz/download/zips/dfa.zip
    NET_WORTH_DATA_CSV = "dfa/dfa-networth-levels.csv"

    # Step 1: Calculate total wealth gains tax per quarter
    with open(NET_WORTH_DATA_CSV) as csv_file:
        for line in csv_file:
            if "TopPt1" in line or "RemainingTop1" in line:
                columns = line.split(',')
                date = columns[0]
                net_worth = int(columns[2]) * 1_000_000  # Number in millions
                curr_net_worth += net_worth
            else:
                if date is not None:
                    delta_net_worth = curr_net_worth - last_net_worth
                    tax_revenue = max(0.0, delta_net_worth * TAX_RATE)

                    tax_revenue_dict[date] = tax_revenue

                    last_net_worth = curr_net_worth
                    curr_net_worth = 0
                    date = None
    with open("1-tax_revenue_dict.json", 'w') as json_file:
        json_file.write(json.dumps(tax_revenue_dict, indent=2))

    # Step 2: Calculate annual tax relief, assuming tax relief is uniformly applied across all tax returns
    annual_tax_relief_dict = dict()
    annual_tax_revenue = 0
    curr_date = ""
    for date, revenue in tax_revenue_dict.items():
        annual_tax_revenue += revenue
        if "Q1" in date:
            curr_date = date
        elif curr_date and "Q4" in date:
            year = int(curr_date.split(':')[0])
            annual_tax_relief_dict[year] = round(annual_tax_revenue / NUM_WORKERS, 2)
            annual_tax_revenue = 0
    with open("2-annual_tax_relief.json", 'w') as json_file:
        json_file.write(json.dumps(annual_tax_relief_dict, indent=2))

    # generate_html_table()
