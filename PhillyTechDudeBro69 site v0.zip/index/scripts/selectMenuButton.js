$(document).ready(function() {
    var homeMenuButton = document.getElementById("homeTopbar");
    homeMenuButton.classList.remove("menuButton");
    homeMenuButton.classList.add("menuButtonSelected");
});